<?php
    require_once("Layout.php"); 
?>

<footer class="sticky-footer text-back">
    <div class="container">
        <div class="copyright text-center my-auto">
            <h4>Copyright &copy; Support Express 2022</h4>
        </div>
    </div>
</footer>