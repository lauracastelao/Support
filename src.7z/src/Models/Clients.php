<?php

namespace App\Models;

use App\Database;

class clients {
    private ?int $id;
    private string $client;
    private ?string $date_time;
    private string $issue;
    private $database;
    private $table = "appointments";
    
    public function __construct( int $id = null, string $client = '', string $issue = '',string $detail='', string $date_time = '')
    {
        $this->date_time = $date_time;
        $this->client = $client;
        $this->issue = $issue;
        $this->detail = $detail;
        $this->id = $id;

        if (!$this->database) {
            $this->database = new Database;
            
        }
    }

    public function getdate_time()
    {
        return $this->date_time;
    }

    public function getissue()
    {
        return $this->issue;
    }
    public function getdetail()
    {
        return $this->detail;
    }

    public function getId()
    {
        return $this->id;
    }

    public function getclient()
    {
        return $this->client;
    }

    public function rename($client,$issue)
    {
        $this->client = $client;
        $this->issue = $issue;
        
    }

    public function save(): void
    {
        $this->database->mysql->query("INSERT INTO `{$this->table}` (`client`, `issue`) VALUES ('$this->client','$this->issue');");
    }

    public function all()
    {
        $query = $this->database->mysql->query("select * FROM {$this->table}");
        $clientsArray = $query->fetchAll();
                
        $clientList = [];
        
        foreach ($clientsArray as $client) {
            $clientItem = new Clients ($client["id"], $client["client"], $client["issue"], $client["date_time"]);
            
            array_push($clientList, $clientItem);
        }
        
        return $clientList;
    }


    public function delete()
    {
        
        $query = $this->database->mysql->query("DELETE FROM `{$this->table}` WHERE `{$this->table}`.`id` = {$this->id}");
    }

    public function findById($id)
    {
        $query = $this->database->mysql->query("SELECT * FROM `{$this->table}` WHERE `id` = {$id}");
        $result = $query->fetchAll();

        return new Clients($result[0]["id"], $result[0]["client"], $result[0]["issue"] , $result[0]["date_time"]);
    }


    public function Update()
    {
        $this->database->mysql->query("UPDATE `{$this->table}` SET `client` =  '{$this->client}', `issue` =  '{$this->issue}' WHERE `id` = {$this->id}");
    }
}